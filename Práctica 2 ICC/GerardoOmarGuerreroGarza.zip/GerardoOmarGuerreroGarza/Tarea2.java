public class Tarea2 {
    public static void main(String[] args){

	int x=369;
	String hola= "hola";
	float w= 3.141516f;
	double número= 46.69686869696869696868;
	char letra = 'g';
	boolean verdadero = true;
	
	    
	    System.out.println("Ejemplo de un entero: "+x);
	    System.out.println("Ejemplo de un String: " + hola);
		System.out.println("Ejemplo de un float: " + w);
		System.out.println("Ejemplo de un double: " + número);
		System.out.println("Ejemplo de un char: " + letra);
		System.out.println("Ejemplo de un boolean: " + verdadero);
    }
}
