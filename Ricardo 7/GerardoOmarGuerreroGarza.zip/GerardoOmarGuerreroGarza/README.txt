Nombre del alumno: Gerardo Omar Guerrero Garza 

Hola Ricardo, para el programa de la lectura y escritura de archivos (txt.java) ya cree el archivo (Archivo.txt) y es el que se debe poner en la terminal, ya tiene números de acuerdo al formato pero si quieres puedes poner otros siguiendo el mismo formato y el programa funciona igual. 
