Gerardo Omar Guerrero Garza 
