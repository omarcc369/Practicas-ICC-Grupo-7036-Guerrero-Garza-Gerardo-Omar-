Nombre del alumno: Guerrero Garza Gerardo Omar
Número de cuenta: 322324217

